module.exports = {
  // RAZORPAY_API_KEY: 'rzp_live_QQgELRZbwLTE2n',
  RAZORPAY_API_KEY: 'rzp_test_ug6gBARp85Aq1j',
  RAZORPAY_API_SECRET: 'KhL8eSr6Vxo4vvhbHpu27mwx'
};

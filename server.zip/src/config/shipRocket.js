require('dotenv').config();

module.exports = {
  shiprocketApiSecret: process.env.SHIPROCKET_API_SECRET,
};

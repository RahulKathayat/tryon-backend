
const express=require('express');
// const User= require('./config');
const app=express();
app.use(express.json());

//---------------setting the firebase---------------------------------
var admin = require("firebase-admin"); 
var {firebaseConfig} = require("./firebase"); // download the key 
admin.initializeApp({
  credential: admin.credential.cert(firebaseConfig)
});

//----------------connecting to the firebase Storage--------------------
const db=admin.firestore();
const User=db.collection("Users")

//----------------------get api------------------------------------------
const callFunction= async()=>{
    app.get("/", async (req, res) => {
        const getdata = await users.get();
        const list = getdata.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
        res.send(list);
      });
}

callFunction()



//------------------------post api----------------------------------------
app.post("/create", async (req, res) => {
    const data = req.body;
    await User.add({ data });
    res.send({ msg: "User Added" });
  });


app.listen(3000,()=>console.log("Connected to the server.............."))

# multibrand-api

NODE_ENV=development pm2 start ecosystem.config.json --no-daemon
